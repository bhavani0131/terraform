import os
import json
import boto3
import pymysql

def lambda_handler(event, context):
    secret_name = os.environ['SECRET_NAME']
    db_host = os.environ['DB_HOST']
    
    # 1. Fetch secrets privately via Interface VPC Endpoint
    secrets_client = boto3.client('secretsmanager')
    try:
        secret_response = secrets_client.get_secret_value(SecretId=secret_name)
        credentials = json.loads(secret_response['SecretString'])
        db_user = credentials['username']
        db_password = credentials['password']
    except Exception as e:
        return {'statusCode': 500, 'body': f"Failed fetching secret: {str(e)}"}

    # 2. Establish private DB connection and build structures inside MySQL
    try:
        connection = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            connect_timeout=5,
            autocommit=True # Saves table records and actions immediately
        )
        
        with connection.cursor() as cursor:
            # Create structural database components if missing
            cursor.execute("CREATE DATABASE IF NOT EXISTS practice_db;")
            cursor.execute("USE practice_db;")
            
            # Create a user table schema layout
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL,
                    email VARCHAR(50) NOT NULL
                );
            """)
            
            # Seed our practice record inside the users array table
            cursor.execute("INSERT INTO users (name, email) VALUES ('Durga Bhavani', 'durga@example.com');")
            
            # Read everything back to confirm it works
            cursor.execute("SELECT * FROM users;")
            all_users = cursor.fetchall()
            
        connection.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'status': 'Success',
                'message': 'Database and users table created successfully!',
                'current_rows_in_db': all_users
            })
        }
    except Exception as e:
        return {'statusCode': 500, 'body': f"Database Action Error: {str(e)}"}
